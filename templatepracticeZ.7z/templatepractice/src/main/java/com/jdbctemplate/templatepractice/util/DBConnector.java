package com.jdbctemplate.templatepractice.util;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnector {

	private static final String url="jdbc:mysql://localhost:3306/bankdb";
	private static final String username="root";
	private static final String password="Root123$";
	private static Connection connection;
	
	public static Connection getConnection() throws SQLException{
		if(connection==null || connection.isClosed()) {	
	try {
		Class.forName("com.mysql.cj.jdbc.Driver");
	}
	catch(ClassNotFoundException e) {
		throw new SQLException("Driver not found");
	}

		connection=DriverManager.getConnection(url,username,password);
	}
		return connection;
	}
	
	
}






