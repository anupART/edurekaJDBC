package com.jdbctemplate.templatepractice.dao;



import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.jdbctemplate.templatepractice.model.Transaction;
import com.jdbctemplate.templatepractice.util.DBConnector;

@Repository
public class TransactionDAOImpl implements TransactionDAO {
//
//    private JdbcTemplate jdbcTemplate;
//
//    // Setter for Spring to inject JdbcTemplate
//    public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
//        this.jdbcTemplate = jdbcTemplate;
//    }
	
	@Autowired
    private JdbcTemplate jdbcTemplate;

    // Add Transaction
    @Override
    public boolean addTransaction(Transaction tx) {
        String sql = "INSERT INTO transactions(userid, type, amount, timestamp, receiverid) VALUES (?, ?, ?, ?, ?)";
        Object[] params = new Object[] {
            tx.getUserId(),
            tx.getType().toLowerCase(),
            tx.getAmount(),
            tx.getTimestamp(),
            tx.getReceiverId()
        };
        int rows = jdbcTemplate.update(sql, params);
        return rows > 0;
    }

    
    @Override
    public List<Transaction> getTransactionsByUserId(int userId) {
        String sql = "SELECT * FROM transactions WHERE userid = ? ORDER BY timestamp DESC";

        return jdbcTemplate.query(sql, transactionRowMapper, userId);
    }

    private RowMapper<Transaction> transactionRowMapper = new RowMapper<Transaction>() {
        @Override
        public Transaction mapRow(ResultSet rs, int rowNum) throws SQLException {
            Integer receiverId = rs.getObject("receiverid") != null ? rs.getInt("receiverid") : null;
            return new Transaction(
                    rs.getInt("id"),
                    rs.getInt("userid"),
                    rs.getString("type"),
                    rs.getDouble("amount"),
                    rs.getTimestamp("timestamp"),
                    receiverId
            );
        }
    };
}





