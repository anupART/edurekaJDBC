package com.jdbctemplate.templatepractice.model;

import java.sql.Timestamp;

public class Transaction {
    private int id;
    private int userId;
    private String type; 
    private double amount;
    private Timestamp timestamp;
    private Integer receiverId; 


    public Transaction() {}

    public Transaction(int id, int userId, String type, double amount, Timestamp timestamp, Integer receiverId) {
        this.id = id;
        this.userId = userId;
        this.type = type;
        this.amount = amount;
        this.timestamp = timestamp;
        this.receiverId = receiverId;
    }

    public Transaction(int userId, String type, double amount, Timestamp timestamp, Integer receiverId) {
        this.userId = userId;
        this.type = type;
        this.amount = amount;
        this.timestamp = timestamp;
        this.receiverId = receiverId;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public Timestamp getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(Timestamp timestamp) {
        this.timestamp = timestamp;
    }

    public Integer getReceiverId() {
        return receiverId;
    }

    public void setReceiverId(Integer receiverId) {
        this.receiverId = receiverId;
    }
    
    @Override
    public String toString() {
        return String.format("ID: %d | Type: %s | Amount: ₹%.2f | Time: %s%s",
            id, type, amount, timestamp.toLocalDateTime(),
            (receiverId != null ? " | Receiver ID: " + receiverId : ""));
    }

}





