package com.jdbctemplate.templatepractice.service;


import java.util.List;

import com.jdbctemplate.templatepractice.model.Transaction;



public interface TransactionService {
    List<Transaction> getTransactionHistory(int userId);

}



