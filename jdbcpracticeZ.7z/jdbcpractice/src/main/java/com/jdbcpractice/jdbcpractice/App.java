package com.jdbcpractice.jdbcpractice;


import com.jdbcpractice.jdbcpractice.model.User;
import com.jdbcpractice.jdbcpractice.model.Transaction;
import com.jdbcpractice.jdbcpractice.service.UserService;
import com.jdbcpractice.jdbcpractice.service.UserServiceImpl;
import com.jdbcpractice.jdbcpractice.service.TransactionService;
import com.jdbcpractice.jdbcpractice.service.TransactionServiceImpl;

import java.util.List;
import java.util.Scanner;

public class App {
    private static final Scanner sc = new Scanner(System.in);
    private static final UserService userService = new UserServiceImpl();
    private static final TransactionService txService = new TransactionServiceImpl();
    private static User loggedInUser = null;
    private static boolean isValidEmail(String email) {
        return email.matches("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$");
    }
    private static boolean isValidPassword(String password) {
        return password.length() >= 6 && password.matches(".*[A-Za-z].*") && password.matches(".*\\d.*");
    }

    
    public static void main(String[] args) {
    	
    	
    	
        while (true) {
            System.out.println("\n=== Bank Application ===");
            System.out.println("1. Register");
            System.out.println("2. Login");
            System.out.println("3. Exit");
            System.out.print("Select option: ");
            
            int choice = readIntInput();

            switch (choice) {
                case 1:
                    register();
                    break;
                case 2:
                    login();
                    break;
                case 3:
                    System.out.println("Thank you! Exiting.");
                    return;
                default:
                    System.out.println("Invalid choice!");
            }
        }
    }

    private static void register() {
        sc.nextLine(); // flush newline
        System.out.print("Enter name: ");
        String name = sc.nextLine();
        String email;
        do {
            System.out.print("Enter email: ");
            email = sc.nextLine();
            if (!isValidEmail(email)) {
                System.out.println("Invalid email format. Try again.");
            }
        } while (!isValidEmail(email));
        
        String password;
        do {
            System.out.print("Enter password (min 6 chars, must contain letter & digit): ");
            password = sc.nextLine();
            if (!isValidPassword(password)) {
                System.out.println("Weak password. Try again.");
            }
        } while (!isValidPassword(password));
        
        User user = new User(0, name, email, password, 0.0);
        if (userService.registerUser(user)) {
            System.out.println("Registration successful!");
        } else {
            System.out.println("Registration failed! Email might be in use.");
        }
    }

    private static void login() {
        sc.nextLine(); 
        String email;
        do {
            System.out.print("Enter email: ");
            email = sc.nextLine();
            if (!isValidEmail(email)) {
                System.out.println("Invalid email format.");
            }
        } while (!isValidEmail(email));
        System.out.print("Enter password: ");
        String password = sc.nextLine();

        loggedInUser = userService.login(email, password);
        if (loggedInUser != null) {
            System.out.println("Login successful. Welcome, " + loggedInUser.getName());
            loggedInMenu();
        } else {
            System.out.println("Invalid credentials!");
        }
    }

    private static void loggedInMenu() {
        while (true) {
            System.out.println("\n--- User Menu ---");
            System.out.println("1. View Balance");
            System.out.println("2. Deposit");
            System.out.println("3. Withdraw");
            System.out.println("4. Transfer");
            System.out.println("5. Transaction History");
            System.out.println("6. Logout");
            System.out.print("Select option: ");

            int choice = readIntInput();

            switch (choice) {
                case 1:
                    System.out.println("Balance: ₹" + userService.getBalance(loggedInUser.getId()));
                    break;
                case 2:
                    deposit();
                    break;
                case 3:
                    withdraw();
                    break;
                case 4:
                    transfer();
                    break;
                case 5:
                    showHistory();
                    break;
                case 6:
                    loggedInUser = null;
                    System.out.println("Logged out successfully.");
                    return;
                default:
                    System.out.println("Invalid choice!");
            }
        }
    }

    private static void deposit() {
        System.out.print("Enter amount to deposit: ");
        double amount = readDoubleInput();
        if (amount <= 0) {
            System.out.println("Amount must be greater than zero.");
            return;
        }
        if (userService.deposit(loggedInUser.getId(), amount)) {
            System.out.println("Deposit successful.");
        } else {
            System.out.println("Deposit failed.");
        }
    }

    private static void withdraw() {
        System.out.print("Enter amount to withdraw: ");
        double amount = readDoubleInput();
        if (amount <= 0) {
            System.out.println("Amount must be greater than zero.");
            return;
        }
        if (userService.withdraw(loggedInUser.getId(), amount)) {
            System.out.println("Withdrawal successful.");
        } else {
            System.out.println("Insufficient balance or error.");
        }
    }

    private static void transfer() {
        System.out.print("Enter receiver user ID: ");
        int receiverId = readIntInput();
        System.out.print("Enter amount to transfer: ");
        double amount = readDoubleInput();
        if (amount <= 0) {
            System.out.println("Amount must be greater than zero.");
            return;
        }
        if (userService.transfer(loggedInUser.getId(), receiverId, amount)) {
            System.out.println("Transfer successful.");
        } else {
            System.out.println("Transfer failed (invalid ID or insufficient balance).");
        }
    }

    private static void showHistory() {
        List<Transaction> txList = txService.getTransactionHistory(loggedInUser.getId());
        if (txList.isEmpty()) {
            System.out.println("No transactions found.");
        } else {
            System.out.println("\nTransaction History:");
            for (Transaction tx : txList) {
                System.out.println(tx); 
            }
        }
    }

    private static int readIntInput() {
        while (true) {
            if (sc.hasNextInt()) {
                return sc.nextInt();
            } else {
                System.out.print("Invalid input. Enter a valid number: ");
                sc.next(); 
            }
        }
    }
 
    private static double readDoubleInput() {
        while (true) {
            if (sc.hasNextDouble()) {
                return sc.nextDouble();
            } else {
                System.out.print("Invalid amount. Enter a valid number: ");
                sc.next(); 
            }
        }
    }

}



