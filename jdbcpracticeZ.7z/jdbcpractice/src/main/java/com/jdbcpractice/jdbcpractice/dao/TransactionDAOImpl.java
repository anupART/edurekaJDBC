package com.jdbcpractice.jdbcpractice.dao;



import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.jdbcpractice.jdbcpractice.model.Transaction;
import com.jdbcpractice.jdbcpractice.util.DBConnector;

public class TransactionDAOImpl implements TransactionDAO   {


    @Override
    public boolean addTransaction(Transaction tx) {
        String sql = "INSERT INTO transactions(userid, type, amount, timestamp, receiverid) VALUES (?, ?, ?, ?, ?)";
        try (Connection con = DBConnector.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, tx.getUserId());
            ps.setString(2, tx.getType().toLowerCase());
            ps.setDouble(3, tx.getAmount());
            ps.setTimestamp(4, tx.getTimestamp());
            if (tx.getReceiverId() != null) {
                ps.setInt(5, tx.getReceiverId());
            } else {
                ps.setNull(5, java.sql.Types.INTEGER);
            }
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.out.println("Error adding transaction: " + e.getMessage());
            return false;
        }
    }
    
    
    @Override
    public List<Transaction> getTransactionsByUserId(int userId) {
        String sql = "SELECT * FROM transactions WHERE userid = ? ORDER BY timestamp DESC";
        List<Transaction> list = new ArrayList<>();
        try (Connection con = DBConnector.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, userId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
/*
 If it's a fund transfer, receiver_id will contain the ID of the person receiving money.

But if it's a deposit or withdrawal, there is no receiver, so we must insert NULL in that column.
 * */
                list.add(new Transaction(
                    rs.getInt("id"),
                    rs.getInt("userid"),
                    rs.getString("type"),
                    rs.getDouble("amount"),
                    rs.getTimestamp("timestamp"),
                    rs.getObject("receiverid") != null ? rs.getInt("receiverid") : null
                ));
            }
        } catch (SQLException e) {
            System.out.println("Error fetching transactions: " + e.getMessage());
        }
        return list;
    }
}





