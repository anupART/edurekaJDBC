package com.jdbcpractice.jdbcpractice.service;


import java.util.List;

import com.jdbcpractice.jdbcpractice.dao.*;
import com.jdbcpractice.jdbcpractice.model.Transaction;


public class TransactionServiceImpl  implements TransactionService{
	  private TransactionDAO txDAO = new TransactionDAOImpl();

	    @Override
	    public List<Transaction> getTransactionHistory(int userId) {
	        return txDAO.getTransactionsByUserId(userId);
	    }
	}

