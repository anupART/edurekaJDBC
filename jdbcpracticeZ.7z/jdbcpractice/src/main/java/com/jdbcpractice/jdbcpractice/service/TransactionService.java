package com.jdbcpractice.jdbcpractice.service;


import java.util.List;

import com.jdbcpractice.jdbcpractice.model.Transaction;

public interface TransactionService {
    List<Transaction> getTransactionHistory(int userId);

}



