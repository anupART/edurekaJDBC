package com.jdbcpractice.jdbcpractice.dao;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.jdbcpractice.jdbcpractice.model.User;
import com.jdbcpractice.jdbcpractice.util.DBConnector;

public class UserDAOImpl implements UserDAO {

	@Override
	public boolean registerUser(User user) {
		// TODO Auto-generated method stub
		String sql="insert into bankapp(name,email,password,balance) values(?,?,?,?)";
		try(Connection con=DBConnector.getConnection();
				PreparedStatement ps=con.prepareStatement(sql)){
			ps.setString(1, user.getName());
			ps.setString(2, user.getEmail());
			ps.setString(3,user.getPassword());
			ps.setDouble(4, user.getBalance());
			return ps.executeUpdate()>0;
			
			
		}catch(SQLException e) {
			e.printStackTrace();
			System.out.println("erro registratoon");
			return false;
		}
		
	}

	@Override
	public User login(String email, String password) {
		// TODO Auto-generated method stub
		String sql="select * from bankapp where email=? and password=?";
	try(Connection con=DBConnector.getConnection();
			PreparedStatement ps=con.prepareStatement(sql)){
		ps.setString(1, email);
		ps.setString(2, password);
		ResultSet rs=ps.executeQuery();
		/*
		 return new User(...);
You're not adding anything new to the database.

You're just reading the existing row (i.e., the user that already exists 
in the table), and mapping it into a User Java object so your program can use it.
		 * */
		if(rs.next()) {
			return new User(
					rs.getInt("userid"), rs.getString("name"),   rs.getString("email"),
                    rs.getString("password"),
                    rs.getDouble("balance")
					);
		}
		
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
		return null;
	}

	@Override
	public User getUserById(int id) {
		// TODO Auto-generated method stub
		String sql="select * from bankapp where userid=?";
		try(Connection con=DBConnector.getConnection();
				PreparedStatement ps=con.prepareStatement(sql)){
			ps.setInt(1,id);
			ResultSet rs=ps.executeQuery();
if(rs.next()) {
	return new User(
			  rs.getInt("userid"),
              rs.getString("name"),
              rs.getString("email"),
              rs.getString("password"),
              rs.getDouble("balance"));
}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	@Override
    public List<User> getAllUsers() {
        String sql = "SELECT * FROM bankapp";
        List<User> users = new ArrayList<>();
        try (Connection con = DBConnector.getConnection();
             Statement stmt = con.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                users.add(new User(
                    rs.getInt("userid"),
                    rs.getString("name"),
                    rs.getString("email"),
                    rs.getString("password"),
                    rs.getDouble("balance")
                ));
            }
        } catch (SQLException e) {
            System.out.println("Error listing users: " + e.getMessage());
        }
        return users;
    }



	 @Override
	    public boolean updateBalance(int userId, double newBalance) {
	        String sql = "UPDATE bankapp SET balance = ? WHERE userid = ?";
	        try (Connection con = DBConnector.getConnection();
	             PreparedStatement ps = con.prepareStatement(sql)) {
	            ps.setDouble(1, newBalance);
	            ps.setInt(2, userId);
	            return ps.executeUpdate() > 0;
	        } catch (SQLException e) {
	            System.out.println("Error updating balance: " + e.getMessage());
	            return false;
	        }
	    }
	    
}
	

