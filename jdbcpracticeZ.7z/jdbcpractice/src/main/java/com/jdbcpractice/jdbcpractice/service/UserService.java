package com.jdbcpractice.jdbcpractice.service;


import com.jdbcpractice.jdbcpractice.model.User;

public interface UserService {
    boolean registerUser(User user);
    User login(String email, String password);
    double getBalance(int userId);
    boolean deposit(int userId, double amount);
    boolean withdraw(int userId, double amount);
    boolean transfer(int senderId, int receiverId, double amount);
}




