package com.jdbcpractice.jdbcpractice.dao;


import java.util.List;

import com.jdbcpractice.jdbcpractice.model.Transaction;

public interface TransactionDAO {

	boolean addTransaction(Transaction tx);
	/*
	 You want to insert a transaction into the database.
	 You're executing an INSERT operation.

Return true → if the transaction was recorded successfully

Return false → if it failed (e.g., DB error)
	 * */
	List<Transaction> getTransactionsByUserId(int userId);
	//You're asking: "Give me all transactions where this user is involved (as sender)."
/*
  Why List<Transaction> as return type?
A user may have many transactions:

Deposits

Withdrawals

Transfers
 * */

}
