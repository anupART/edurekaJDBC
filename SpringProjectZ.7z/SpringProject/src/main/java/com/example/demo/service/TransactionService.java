package com.example.demo.service;

import com.example.demo.model.Transaction;
import java.util.List;

public interface TransactionService {
    boolean addTransaction(Transaction transaction);
    List<Transaction> getTransactionHistory(int userId);
    List<Transaction> getAllTransactions();
}
