package com.example.demo.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.Table;
import java.sql.Timestamp;
import io.swagger.v3.oas.annotations.media.Schema;

@Entity
@Table(name = "transactions")  
public class Transaction {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)  
    private int id;

    @ManyToOne
    @JoinColumn(name = "userId", referencedColumnName = "id")
    private User user;  
    
    @Schema(description = "Transaction Type")
    private String type; 
    
    @Schema(description = "Transaction Amount")
    private double amount;
    
    @Schema(description = "Transaction Timestamp")
    private Timestamp timestamp;
    
    @Schema(description = "Receiver ID Amount to send")
    private Integer receiverId;  


    public Transaction() {}

    public Transaction(int id, int userId, String type, double amount, Timestamp timestamp, Integer receiverId) {
        this.id = id;
        this.user = new User();  
        this.user.setId(userId); 
        this.type = type;
        this.amount = amount;
        this.timestamp = timestamp;
        this.receiverId = receiverId;
    }
    public Transaction(int userId, String type, double amount, Timestamp timestamp, Integer receiverId) {
        this.user = new User();
        this.user.setId(userId); 
        this.type = type;
        this.amount = amount;
        this.timestamp = timestamp;
        this.receiverId = receiverId;
    }
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public Timestamp getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(Timestamp timestamp) {
        this.timestamp = timestamp;
    }

    public Integer getReceiverId() {
        return receiverId;
    }

    public void setReceiverId(Integer receiverId) {
        this.receiverId = receiverId;
    }

    @Override
    public String toString() {
        return String.format("ID: %d | Type: %s | Amount: ₹%.2f | Time: %s%s",
            id, type, amount, timestamp.toLocalDateTime(),
            (receiverId != null ? " | Receiver ID: " + receiverId : ""));
    }
}
