package com.example.demo.service;

import com.example.demo.model.Transaction;
import com.example.demo.dao.TransactionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class TransactionServiceImpl implements TransactionService {

    @Autowired
    private TransactionRepository transactionRepository;
    @Override
    public boolean addTransaction(Transaction transaction) {
        if (transaction.getAmount() <= 0) {
            System.out.println("Transaction amount must be greater than zero.");
            return false;
        }
//        System.out.println("Adding transaction: " + transaction);
        transactionRepository.save(transaction);
        return true;  
    }
    @Override
    public List<Transaction> getTransactionHistory(int userId) {
        return transactionRepository.findByUserIdOrderByTimestampDesc(userId);
    }
    @Override
    public List<Transaction> getAllTransactions() {
        return transactionRepository.findAll();
    }
}
