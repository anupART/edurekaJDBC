package com.example.demo.service;

import com.example.demo.dao.TransactionRepository;
import com.example.demo.dao.UserRepository;
import com.example.demo.model.Transaction;
import com.example.demo.model.User;
 // Correct import for UserRepository
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.sql.Timestamp;

@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private UserRepository userRepo;  

    @Autowired
    private TransactionService txService;

	public void setUserRepo(UserRepository userRepo) {
	    this.userRepo = userRepo;
	}

	public void setTxService(TransactionService txService) {
	    this.txService = txService;
	}


    
    @Override
    public boolean registerUser(User user) {
        return userRepo.save(user) != null;  
    }

    @Override
    public User login(String email, String password) {
        return userRepo.findByEmailAndPassword(email, password);  
    }

    @Override
    public double getBalance(int userId) {
        return userRepo.findById(userId).map(User::getBalance).orElse(-1.0);  
    }

    @Override
    public boolean deposit(int userId, double amount) {
        return userRepo.findById(userId).map(user -> {
            user.setBalance(user.getBalance() + amount);
            userRepo.save(user);  
            txService.addTransaction(new Transaction(0, userId, "deposit", amount, new Timestamp(System.currentTimeMillis()), null));
            return true;
        }).orElse(false);
    }

    @Override
    public boolean withdraw(int userId, double amount) {
        return userRepo.findById(userId).map(user -> {
            if (user.getBalance() >= amount) {
                user.setBalance(user.getBalance() - amount);
                userRepo.save(user);  
                txService.addTransaction(new Transaction(0, userId, "withdraw", amount, new Timestamp(System.currentTimeMillis()), null));
                return true;
            }
            return false;
        }).orElse(false);
    }

    @Override
    public boolean transfer(int senderId, int receiverId, double amount) {
        User sender = userRepo.findById(senderId).orElse(null);
        User receiver = userRepo.findById(receiverId).orElse(null);

        if (sender == null || receiver == null || sender.getBalance() < amount || amount <= 0) {
            return false;
        }

        sender.setBalance(sender.getBalance() - amount);
        receiver.setBalance(receiver.getBalance() + amount);
        userRepo.save(sender);  // Persist updated sender
        userRepo.save(receiver);  // Persist updated receiver

        Timestamp now = new Timestamp(System.currentTimeMillis());
        txService.addTransaction(new Transaction(0, senderId, "transfer", amount, now, receiverId));
        txService.addTransaction(new Transaction(0, receiverId, "deposit", amount, now, senderId));
        return true;
    }
}
