package com.example.demo.controller;

import com.example.demo.model.User;
import com.example.demo.service.UserService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.test.web.servlet.MockMvc;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

@WebMvcTest(UserController.class)
public class UserControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private UserService userService;

    @Autowired
    private ObjectMapper objectMapper;

    private User user;

    @BeforeEach
    public void setUp() {
        user = new User("Anup", "anup@gmail.com", "password", 1000);
    }

    @Test
    void testRegisterUser() throws Exception {
        when(userService.registerUser(any(User.class))).thenReturn(true);
        mockMvc.perform(MockMvcRequestBuilders.post("/api/v1/banks/register")
                .contentType("application/json")
                .content(objectMapper.writeValueAsString(user)))
                .andExpect(status().isOk());
        }

    @Test
    void testLoginUser() throws Exception {
        when(userService.login("anup@gmail.com", "password")).thenReturn(user);
        mockMvc.perform(MockMvcRequestBuilders.post("/api/v1/banks/login")
                .param("email", "anup@gmail.com")
                .param("password", "password"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.name").value("Anup"))
                .andExpect(jsonPath("$.email").value("anup@gmail.com"));
    }

    @Test
    void testGetBalance() throws Exception {
        when(userService.getBalance(1)).thenReturn(1000.0);
        mockMvc.perform(MockMvcRequestBuilders.get("/api/v1/banks/balance/1"))
                .andExpect(status().isOk());
        }

    @Test
    void testDeposit() throws Exception {
        when(userService.deposit(1, 500.0)).thenReturn(true);
        mockMvc.perform(MockMvcRequestBuilders.post("/api/v1/banks/deposit/1")
                .param("amount", "500"))
                .andExpect(status().isOk());
        }

    @Test
    void testWithdraw() throws Exception {
        when(userService.withdraw(1, 500.0)).thenReturn(true);
        mockMvc.perform(MockMvcRequestBuilders.post("/api/v1/banks/withdrawn/1")
                .param("amount", "500"))
                .andExpect(status().isOk());
        }

    @Test
    void testTransfer() throws Exception {
        when(userService.transfer(1, 2, 500.0)).thenReturn(true);
        mockMvc.perform(MockMvcRequestBuilders.post("/api/v1/banks/transfer")
                .param("senderId", "1")
                .param("reciverId", "2")
                .param("amount", "500"))
                .andExpect(status().isOk());
        }
}
