package com.example.demo.service;

import com.example.demo.dao.TransactionRepository;
import com.example.demo.model.Transaction;
import com.example.demo.model.User;
import com.example.demo.service.TransactionServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.sql.Timestamp;
import java.util.Arrays;
import java.util.List;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

class TransactionServiceImplTest {

    @Mock
    private TransactionRepository transactionRepository;
    @InjectMocks
    private TransactionServiceImpl transactionService;
    private Transaction transaction;
    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);  
        transaction = new Transaction(1, "Deposit", 1000.0, new Timestamp(System.currentTimeMillis()), 2);
    }

    @Test
    void addTransactionTest() {
        when(transactionRepository.save(any(Transaction.class))).thenReturn(transaction);
        boolean result = transactionService.addTransaction(transaction);
        assertTrue(result);    }


    @Test 
    void transactionHistory() {
        List<Transaction> transactions = Arrays.asList(transaction, new Transaction(2, "Transfer", 500.0, new Timestamp(System.currentTimeMillis()), 3));
        when(transactionRepository.findByUserIdOrderByTimestampDesc(1)).thenReturn(transactions);
        List<Transaction> result = transactionService.getTransactionHistory(1);
        assertEquals(2, result.size());
    }

}