package com.example.demo.service;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.example.demo.dao.UserRepository;
import com.example.demo.model.User;

public class UserServiceImplTest {

    @Mock
    private UserRepository userRepository;
    
    @Mock
    private TransactionService txService;

    
    private UserServiceImpl userService;
    
    

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
        userService = new UserServiceImpl();
        userService.setUserRepo(userRepository);
        userService.setTxService(txService);
    }

    @Test
    public void registerUserTest() {
        User user = new User(1, "Anup", "anup@gmail.com", "1234567", 20);
        when(userRepository.save(user)).thenReturn(user);
        boolean result = userService.registerUser(user);
        assertTrue(result);
        assertNotNull(user);
    }

    @Test
    public void loginValidUserTest() {
        String email = "anup@gmail.com";
        String password = "1234567";
        User user = new User(email, password);
        when(userRepository.findByEmailAndPassword(email, password)).thenReturn(user);
        User loggedInUser = userService.login(email, password);
//        boolean result=userService.login(loggedInUser);
        assertNotNull(loggedInUser);
        assertEquals(email, loggedInUser.getEmail());
//        assertTrue(loggedInUser);
    }


    @Test
    public void balanceTest() {
        User user = new User();
        user.setBalance(5);
        when(userRepository.findById(1)).thenReturn(Optional.of(user));
        double balance = userService.getBalance(1);
        assertEquals(5, balance);
    }

	@Test
	public void depositTest() {
	User user = new User();
	user.setBalance(5);
	when(userRepository.findById(1)).thenReturn(Optional.of(user));
	boolean result = userService.deposit(1, 15);
	assertTrue(result);
	assertEquals(20, user.getBalance());
	}

    @Test
    public void withdrawTest() {
        User user = new User();
        user.setBalance(20);
        when(userRepository.findById(1)).thenReturn(Optional.of(user));
        boolean result = userService.withdraw(1, 5);
        assertTrue(result);
        assertEquals(15, user.getBalance());
    }


    @Test
    public void transferTest() {
        User sender = new User();
        sender.setBalance(50);
        User receiver = new User();
        receiver.setBalance(50);
        when(userRepository.findById(1)).thenReturn(Optional.of(sender));
        when(userRepository.findById(2)).thenReturn(Optional.of(receiver));
        boolean result = userService.transfer(1, 2, 20);
        assertTrue(result);
        assertEquals(30, sender.getBalance());
        assertEquals(70, receiver.getBalance());
    }


}
