
package com.example.demo.model;

import java.sql.Timestamp;

import io.swagger.v3.oas.annotations.media.Schema;

@Schema(description="Transaction Entity")
public class Transaction {
	
	@Schema(description="Transaction ID")
    private int id;
	@Schema(description="User ID in Transaction")
    private int userId;
	@Schema(description="Transaction Type")
    private String type; 
	@Schema(description="Transaction Amount")
    private double amount;
	@Schema(description="Transaction timetamp")
    private Timestamp timestamp;
	@Schema(description="Receiver ID Amount to send")
    private Integer receiverId; 


    public Transaction() {}

    public Transaction(int id, int userId, String type, double amount, Timestamp timestamp, Integer receiverId) {
        this.id = id;
        this.userId = userId;
        this.type = type;
        this.amount = amount;
        this.timestamp = timestamp;
        this.receiverId = receiverId;
    }

    public Transaction(int userId, String type, double amount, Timestamp timestamp, Integer receiverId) {
        this.userId = userId;
        this.type = type;
        this.amount = amount;
        this.timestamp = timestamp;
        this.receiverId = receiverId;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public Timestamp getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(Timestamp timestamp) {
        this.timestamp = timestamp;
    }

    public Integer getReceiverId() {
        return receiverId;
    }

    public void setReceiverId(Integer receiverId) {
        this.receiverId = receiverId;
    }
    
    @Override
    public String toString() {
        return String.format("ID: %d | Type: %s | Amount: ₹%.2f | Time: %s%s",
            id, type, amount, timestamp.toLocalDateTime(),
            (receiverId != null ? " | Receiver ID: " + receiverId : ""));
    }

}





