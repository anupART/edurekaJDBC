package com.example.demo.model;

import io.swagger.v3.oas.annotations.media.Schema;

@Schema(description="User Entity")
public class User {
	
	@Schema(description="Unique ID")
    private int id;
	@Schema(description="Name of User")
    private String name;
	@Schema(description="Email of User")
    private String email;
	@Schema(description="Password of User")
    private String password;
	@Schema(description="Balance/Amount of User")
    private double balance;

    public User() {}

    public User(int id, String name, String email, String password, double balance) {
        this.id = id;
        this.name = name;
        this.email = email;
        this.password = password;
        this.balance = balance;
    }

    public User(String name, String email, String password, double balance) {
        this.name = name;
        this.email = email;
        this.password = password;
        this.balance = balance;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }
}



