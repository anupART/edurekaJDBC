package com.example.demo.service;

import com.example.demo.dao.*;
import com.example.demo.model.*;
import com.example.*;


import java.sql.Timestamp;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
public class UserServiceImpl  implements UserService{

//	private UserDAO userDAO = new UserDAOImpl();
//    private TransactionDAO txDAO = new TransactionDAOImpl();
//    private UserDAO userDAO;
//
//    public void setUserDao(UserDAO userDAO) {
//        this.userDAO = userDAO;
//    }


	    @Autowired
	    private TransactionDAO txDAO;
    
    @Autowired
    private UserDAO userDAO;
    public void setUserDao(UserDAO userDAO) {
        this.userDAO = userDAO;
    }

	@Override
	public boolean registerUser(User user) {
		// TODO Auto-generated method stub
		return userDAO.registerUser(user) ;
	}

	@Override
	public User login(String email, String password) {
		// TODO Auto-generated method stub
		return userDAO.login(email, password);
	}

	@Override
	public double getBalance(int userId) {
		// TODO Auto-generated method stub
		User user=userDAO.getUserById(userId);
		return (user!=null)?user.getBalance():-1;
	}

	@Override
	public boolean deposit(int userId, double amount) {
		// TODO Auto-generated method stub
		User user=userDAO.getUserById(userId);
		if (user == null || amount <= 0) return false;

        double newBalance = user.getBalance() + amount;
        boolean updated = userDAO.updateBalance(userId, newBalance);
        if (updated) {
            Transaction tx = new Transaction(0, userId, "deposit", amount, new Timestamp(System.currentTimeMillis()), null);
            txDAO.addTransaction(tx);
        }
        return updated;
    }

	@Override
	public boolean withdraw(int userId, double amount) {
		User user = userDAO.getUserById(userId);
        if (user == null || amount <= 0 || user.getBalance() < amount) return false;

        double newBalance = user.getBalance() - amount;
        boolean updated = userDAO.updateBalance(userId, newBalance);
        if (updated) {
            Transaction tx = new Transaction(0, userId, "withdraw", amount, new Timestamp(System.currentTimeMillis()), null);
            txDAO.addTransaction(tx);
        }
        return updated;
    }

	public boolean transfer(int senderId, int receiverId, double amount) {
	    User sender = userDAO.getUserById(senderId);
	    User receiver = userDAO.getUserById(receiverId);
	    
	    if (sender == null || receiver == null || amount <= 0 || sender.getBalance() < amount)
	        return false;

	    boolean senderUpdated = userDAO.updateBalance(senderId, sender.getBalance() - amount);
	    boolean receiverUpdated = userDAO.updateBalance(receiverId, receiver.getBalance() + amount);

	    if (senderUpdated && receiverUpdated) {
	        Timestamp ts = new Timestamp(System.currentTimeMillis());
	        txDAO.addTransaction(new Transaction(0, senderId, "transfer", amount, ts, receiverId));
	        txDAO.addTransaction(new Transaction(0, receiverId, "deposit", amount, ts, senderId)); // ✅ corrected
	        return true;
	    }

	    return false;
	}

	}
