package com.example.demo.service;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.dao.*;
import com.example.demo.model.*;



@Service
public class TransactionServiceImpl  implements TransactionService{
//	  private TransactionDAO txDAO = new TransactionDAOImpl();
	  private TransactionDAO txDAO;
//
//	    public void setTransactionDao(TransactionDAO txDAO) {
//	        this.txDAO = txDAO;
//	    }

	    @Autowired
	    private TransactionDAO transactionDAO;
//	    public void setTransactionDao(TransactionDAO transactionDAO) {
//	        this.txDAO = transactionDAO;
//	    }


//	    @Override
//	    public List<Transaction> getTransactionHistory(int userId) {
//	        return txDAO.getTransactionsByUserId(userId);
//	    }
	    @Override
	    public List<Transaction> getTransactionHistory(int userId) {
	        return transactionDAO.getTransactionsByUserId(userId);  // use the autowired field
	    }
	}




