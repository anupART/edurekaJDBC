package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.User;
import com.example.demo.service.UserService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.responses.ApiResponses;

@RestController
@RequestMapping("/api/v1")
public class UserController {
	
	private final UserService  userService;
	@Autowired
	private UserController(UserService  userService) {
		this.userService=userService;
	}
	
	@PostMapping("/banks/register")
	@Operation(summary="Register the user",  description="Returns the New User if new user register or it will return Already Exist" 
//	,responses= { @ApiResponse(responseCode="200")
//			}
)
	
	public String register(
			@Parameter(description="User ID")
			@RequestBody User user) {
		boolean newUser=userService.registerUser(user);
		
		return newUser?"New User":"Already Exist";
		
	}
	
	@PostMapping("/banks/login")
	@Operation(summary="Login the user")
	public User login(@RequestParam String email,@RequestParam String password) {
		return userService.login(email, password);
	}
//	public User login(@PathVariable String email,@PathVariable String password) {
//		return userService.login(email, password);
//	}
	
	@GetMapping("/banks/balance/{id}")
	@Operation(summary="Check the Balance")
	public double getBalance(@PathVariable int id) {
		return userService.getBalance(id);
	}
	
	@PostMapping("/banks/deposit/{id}")
	@Operation(summary="Perform the Deposit")
	public String deposit(@PathVariable int id,@RequestParam double amount) {
		boolean result=userService.deposit(id, amount);
		return result ?"Deposit":"not deposit";
	}
	
	@PostMapping("/banks/withdrawn/{id}")
	@Operation(summary="Perform the WithDrawn")
	public String withdrawn(@PathVariable int id,@RequestParam double amount) {
		boolean result=userService.withdraw(id, amount);
		return result ?"WithDrawn":"not withdrawn";
	}
	
	@PostMapping("/banks/transfer/{id}")
	@Operation(summary="Perform the Trandfer of Amount")
	public String transfer(@RequestParam int senderId,@RequestParam int  reciverId,@RequestParam double amount) {
		boolean result=userService.transfer(senderId, reciverId, amount);
		return result?"Transfer":"Not Transfering";
	}
	
	

}
