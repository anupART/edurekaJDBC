package com.example.demo.dao;

import com.example.demo.model.*;

import java.util.List;

public interface UserDAO {

	boolean registerUser(User user);
	/*
	 This method tries to insert a new user into the database.
→ Returns true if registration (i.e., INSERT query) is successful, otherwise false.

→ It takes a User object that contains name, email, password, and balance.
This way, you can directly map the Java object to your SQL columns.
	 * */
	
	User login(String email,String password);
//	If login is successful, we return a full User object with all details from DB (like id
	
	

	User getUserById(int id);
	//User — because you're fetching one user's data.
	
	List<User> getAllUsers();
	//Return type: List<User> — this returns multiple rows, so it's a list of User objects.


	
	boolean updateBalance(int userid,double newbalance);
	/*
	 Return type: boolean — returns success or failure of the update operation.

Parameters: userId tells which user to update, newBalance is the new amount to store.
	 * */
	
}





