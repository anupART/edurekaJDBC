package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.example.demo.service.TransactionServiceImpl;

import io.swagger.v3.oas.annotations.Operation;

import com.example.demo.model.Transaction;
@RestController
@RequestMapping("api/v1")
public class TransactionController {
//	http://localhost:9090/api/v1/transaction/1
	@Autowired
	private TransactionServiceImpl transactionService;
	
	@GetMapping("transaction/{userId}")
	@Operation(summary="To Perform the transfer")
	public List<Transaction> getTransactionByUser(@PathVariable int userId){
		return transactionService.getTransactionHistory(userId);
	}
	
}
