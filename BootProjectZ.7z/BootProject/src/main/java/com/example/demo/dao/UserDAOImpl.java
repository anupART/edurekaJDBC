package com.example.demo.dao;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;
import com.example.demo.model.*;


@Repository
public class UserDAOImpl implements UserDAO {

//    private JdbcTemplate jdbcTemplate;
//
//    // Spring will inject this
//    public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
//        this.jdbcTemplate = jdbcTemplate;
//    }
    
	
	@Autowired
    private JdbcTemplate jdbcTemplate;

    private RowMapper<User> userRowMapper = new RowMapper<User>() {
        public User mapRow(ResultSet rs, int rowNum) throws SQLException {
            return new User(
                    rs.getInt("userid"),
                    rs.getString("name"),
                    rs.getString("email"),
                    rs.getString("password"),
                    rs.getDouble("balance")
            );
        }
    };

    @Override
    public boolean registerUser(User user) {
        String sql = "INSERT INTO bankapp(name, email, password, balance) VALUES (?, ?, ?, ?)";
        int result = jdbcTemplate.update(sql, user.getName(), user.getEmail(), user.getPassword(), user.getBalance());
        return result > 0;
    }

    @Override
    public User login(String email, String password) {
        String sql = "SELECT * FROM bankapp WHERE email = ? AND password = ?";
        List<User> users = jdbcTemplate.query(sql, userRowMapper, email, password);
        return users.isEmpty() ? null : users.get(0);
    }

    @Override
    public User getUserById(int id) {
        String sql = "SELECT * FROM bankapp WHERE userid = ?";
        List<User> users = jdbcTemplate.query(sql, userRowMapper, id);
        return users.isEmpty() ? null : users.get(0);
    }

    @Override
    public List<User> getAllUsers() {
        String sql = "SELECT * FROM bankapp";
        return jdbcTemplate.query(sql, userRowMapper);
    }

    @Override
    public boolean updateBalance(int userId, double newBalance) {
        String sql = "UPDATE bankapp SET balance = ? WHERE userid = ?";
        int result = jdbcTemplate.update(sql, newBalance, userId);
        return result > 0;
    }
}

