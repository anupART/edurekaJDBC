package com.example.demo;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyDouble;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.jdbc.core.JdbcTemplate;

import com.example.demo.dao.TransactionDAOImpl;
import com.example.demo.dao.UserDAOImpl;
import com.example.demo.model.Transaction;
import com.example.demo.model.User;
import com.example.demo.service.UserServiceImpl;

//@SpringBootTest
@ExtendWith(MockitoExtension.class)
class BootProjectApplicationTests {


	@Mock
	private UserDAOImpl userDao;
	@Mock
	private TransactionDAOImpl tranDao;
	
	@InjectMocks
	private UserServiceImpl userService;


    @Test
    void testRegister() {
    	User mockUser = new User(1, "Anup", "anup@example.com", "password", 1000);
    	when(userDao.registerUser(mockUser)).thenReturn(true);
        boolean isUserRegistered = userService.registerUser(mockUser);
        assertEquals(true,isUserRegistered);
    }
    
    @Test
    void login() {
    	String email="anup@gmail.com";
    	String password="123456789";
    	User user=new User(2,"AA",email,password,1212);
        when(userDao.login(email, password)).thenReturn(user);
    	User logUser=userService.login(email, password);
    	
//    	assertEquals(user.getEmail(),user.getPassword());
    	assertNotNull(logUser);
    	assertEquals(user.getEmail(), logUser.getEmail());
        assertEquals(user.getPassword(), logUser.getPassword());

    	
    }

    
    @Test
    void testDeposit() {
        int userId = 1;
        double depositAmount = 500;
        User user = new User(userId, "Anup", "anup@example.com", "password", 1000);
        when(userDao.getUserById(userId)).thenReturn(user);
        when(userDao.updateBalance(eq(userId), anyDouble())).thenReturn(true);
        boolean deposit = userService.deposit(userId, depositAmount);
        assertTrue(deposit);
        user.setBalance(user.getBalance() + depositAmount);
        assertEquals(1500, user.getBalance(), 0);
    }

    @Test
    void testWithdraw() {
        int id = 1;
        double withdrawAmount = 200;
        User user = new User(id, "Anup", "anup@example.com", "password", 1000);
        when(userDao.getUserById(id)).thenReturn(user);
        when(userDao.updateBalance(eq(id), anyDouble())).thenReturn(true);
        boolean withdraw = userService.withdraw(id, withdrawAmount);
        assertTrue(withdraw);
        user.setBalance(user.getBalance() - withdrawAmount);
        assertEquals(800, user.getBalance(), 0);
    }
    
    @Test
    void testTransfer() {
        int senderId = 1;
        int receiverId = 2;
        double transferAmount = 300;
        User sender = new User(senderId, "Anup", "anup@example.com", "password", 1000);
        User receiver = new User(receiverId, "John", "john@example.com", "password", 500);
        when(userDao.getUserById(senderId)).thenReturn(sender);
        when(userDao.getUserById(receiverId)).thenReturn(receiver);
        when(userDao.updateBalance(eq(senderId), anyDouble())).thenReturn(true);
        when(userDao.updateBalance(eq(receiverId), anyDouble())).thenReturn(true);
        boolean transfer = userService.transfer(senderId, receiverId, transferAmount);
        assertTrue(transfer);
        sender.setBalance(sender.getBalance() - transferAmount);
        receiver.setBalance(receiver.getBalance() + transferAmount);
        assertEquals(700, sender.getBalance(), 0);
        assertEquals(800, receiver.getBalance(), 0);
    }
    

	
}
